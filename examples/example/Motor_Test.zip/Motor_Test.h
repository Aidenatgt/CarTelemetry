#ifndef MyLibrary_h
#define MyLibrary_h

#include "Arduino.h"

class Motor_Test {
public:
    Motor_Test(int pin);
    void setSpeed(int speed);
private:
    int pin;
};

#endif