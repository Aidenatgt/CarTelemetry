#include "Motor_Test.h"

Motor_Test::Motor_Test(int pin) {
    pinMode(pin, OUTPUT);
    Motor_Test::pin = pin;
}

void Motor_Test::setSpeed(int speed) {
    analogWrite(Motor_Test::pin, speed);
}